const $=id=>document.getElementById(id);
const fields=["customer","account","status","invoiceNo","service","originalAmount","originalCurrency","usd","rate","localCurrency","note"];
function calc(){
  $("vCustomer").textContent=$("customer").value;
  $("vAccount").textContent=$("account").value;
  $("vInvoiceNo").textContent=$("invoiceNo").value;
  $("vService").textContent=$("service").value;
  $("vOriginal").textContent=$("originalAmount").value;
  $("vOrigCurrency").textContent=$("originalCurrency").value;
  $("vUsd").textContent=$("usd").value;
  $("vRate").textContent=Number($("rate").value||0).toLocaleString("en-US");
  $("vLocalCurrency").textContent=$("localCurrency").value;
  const total=Number($("usd").value||0)*Number($("rate").value||0);
  $("vTotal").textContent=total.toLocaleString("en-US");
  $("vTotalCurrency").textContent=$("localCurrency").value;
  $("vNote").textContent=$("note").value;
  const s=$("status").value, el=$("vStatus");
  el.className="status "+s.toLowerCase();
  el.textContent=s==="PAID"?"مدفوع — PAID":s==="CANCELLED"?"ملغي — CANCELLED":"مستحق الدفع — PENDING";
  $("vDate").textContent=new Intl.DateTimeFormat("ar-EG",{year:"numeric",month:"long",day:"2-digit"}).format(new Date());
}
fields.forEach(id=>$(id).addEventListener("input",calc));
fields.forEach(id=>$(id).addEventListener("change",calc));
function resetForm(){
  if(confirm("هل تريد مسح البيانات وإعادتها للقيم الافتراضية؟")) location.reload();
}
calc();
